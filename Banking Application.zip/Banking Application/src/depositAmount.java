/*import net.proteanit.sql.DbUtils;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import javax.swing.*;


public class depositAmount extends JFrame implements ActionListener {

    JTable table;
    Choice cAccountId;
    JButton search,back, deposit;

    depositAmount() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setTitle("Meezan Bank - Amount Depositer");

        // Set up icon for the window
        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("icons/meezan.png"));
        Image img = icon.getImage();
        Image scaledImage = img.getScaledInstance(112, 112, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        setIconImage(scaledIcon.getImage());

        //Label for depositing amount
        JLabel depositlbl = new JLabel("Deposit Amount");
        depositlbl.setBounds(450, 20, 150, 20);
        add(depositlbl);

        JTextField depositTF = new JTextField(80);
        depositTF.setBounds(560, 20, 150, 25);
        add(depositTF);

        // Label for account ID search
        JLabel searchLbl = new JLabel("Search by Account ID");
        searchLbl.setBounds(20, 20, 150, 20);
        add(searchLbl);

        // Dropdown for selecting account ID
        cAccountId = new Choice();
        cAccountId.setBounds(180, 20, 150, 25);
        add(cAccountId);

        // Populate account ID dropdown
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT DISTINCT accountId FROM accounts");
            while (rs.next()) {
                cAccountId.add(rs.getString("accountId"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Table to display account details
        table = new JTable();

        // Set up table model with initial data
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM accounts WHERE accountId = '"+cAccountId.getSelectedItem()+"'");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        JScrollPane jsp = new JScrollPane(table);
        jsp.setBounds(0, 100, 900, 600);
        add(jsp);

        // Search button to query account balance
        search = new JButton("Search");
        search.setBounds(70, 70, 80, 20);
        search.addActionListener(this);
        add(search);



        // Print button to print the table view
        deposit = new JButton("Deposit");
        deposit.setBounds(600, 70, 80, 20);
        deposit.addActionListener(this);
        add(deposit);

        // Back button to navigate to previous screen
        back = new JButton("Back");
        back.setBounds(220, 70, 80, 20);
        back.addActionListener(this);
        add(back);

        setSize(900, 700);
        setLocation(300, 100);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == search) {
            String query = "SELECT * FROM accounts WHERE accountId = '"+cAccountId.getSelectedItem()+"'";
            try {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery(query);
                table.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == deposit) {
            try {
                table.;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            setVisible(false);
            // Assuming you have a main banking screen or menu
            new Bank();
        }
    }

    public static void main(String[] args) {
        new depositAmount();
    }
}
*/

import net.proteanit.sql.DbUtils;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import javax.swing.*;

public class depositAmount extends JFrame implements ActionListener {

    JTable table;
    Choice cAccountId;
    JButton search, back, deposit;
    JTextField depositTF;

    depositAmount() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setTitle("Meezan Bank - Deposit Amount");

        // Set up icon for the window
        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("icons/meezan.png"));
        Image img = icon.getImage();
        Image scaledImage = img.getScaledInstance(112, 112, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        setIconImage(scaledIcon.getImage());

        // Label for depositing amount
        JLabel depositlbl = new JLabel("Deposit Amount");
        depositlbl.setBounds(450, 20, 150, 20);
        add(depositlbl);

        depositTF = new JTextField(80);
        depositTF.setBounds(560, 20, 150, 25);
        add(depositTF);

        // Label for account ID search
        JLabel searchLbl = new JLabel("Search by Account ID");
        searchLbl.setBounds(20, 20, 150, 20);
        add(searchLbl);

        // Dropdown for selecting account ID
        cAccountId = new Choice();
        cAccountId.setBounds(180, 20, 150, 25);
        add(cAccountId);

        // Populate account ID dropdown
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM accountdetails");
            while (rs.next()) {
                cAccountId.add(rs.getString("acNum"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Table to display account details
        table = new JTable();
        JScrollPane jsp = new JScrollPane(table);
        jsp.setBounds(0, 100, 900, 600);
        add(jsp);

        // Search button to query account balance
        search = new JButton("Search");
        search.setBounds(70, 70, 80, 20);
        search.addActionListener(this);
        add(search);

        // Deposit button to process the deposit
        deposit = new JButton("Deposit");
        deposit.setBounds(600, 70, 80, 20);
        deposit.addActionListener(this);
        add(deposit);

        // Back button to navigate to previous screen
        back = new JButton("Back");
        back.setBounds(220, 70, 80, 20);
        back.addActionListener(this);
        add(back);

        setSize(900, 700);
        setLocation(300, 100);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == search) {
            String query = "SELECT * FROM accountdetails WHERE accountId = '" + cAccountId.getSelectedItem() + "'";
            try {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery(query);
                table.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == deposit) {
            try {
                String accountId = cAccountId.getSelectedItem();
                int amount = Integer.parseInt(depositTF.getText());

                Conn c = new Conn();
                // Get current balance
                ResultSet rs = c.s.executeQuery("SELECT balance FROM accountdetails WHERE accountId = '" + accountId + "'");
                if (rs.next()) {
                    int balance = rs.getInt("balance");
                    // Update the balance after deposit
                    int newBalance = balance + amount;
                    c.s.executeUpdate("UPDATE accountdetails SET balance = " + newBalance + " WHERE accountId = '" + accountId + "'");

                    // Display the updated information
                    ResultSet rsUpdated = c.s.executeQuery("SELECT * FROM accountdetails WHERE accountId = '" + accountId + "'");
                    table.setModel(DbUtils.resultSetToTableModel(rsUpdated));

                    JOptionPane.showMessageDialog(null, "Deposit successful!");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid amount.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == back) {
            dispose();
            // Assuming you have a main banking screen or menu
            new Bank();
        }
    }

    public static void main(String[] args) {
        new depositAmount();
    }
}

