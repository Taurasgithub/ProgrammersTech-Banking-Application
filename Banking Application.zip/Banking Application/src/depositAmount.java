public class depositAmount {
}
