import java.sql.*;

public class Conn {

    Connection c;
    Statement s;

    String url = "jdbc:mysql://localhost:3306/meezanbank?useSSL=false&characterEncoding=latin1&useConfigs=maxPerformance";
    String user = "root";
    String password = "123456789";

    public Conn () {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection(url, user, password);
            s = c.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
