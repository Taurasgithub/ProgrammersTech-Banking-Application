import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Bank implements ActionListener{
    JFrame F1;
    JPanel P1,P2;
    JLabel heading;
    JButton newAccount, checkBalance, Deposit, Withdraw, Transfer, Exit;
    public Bank(){
    F1 = new JFrame("Meezan Bank Service Portal");
        F1.setLayout(null);

        heading = new JLabel("Meezan Banking Services");
        heading.setBounds(115, 30, 800, 80);
        heading.setFont(new Font("Elephant", Font.BOLD, 45));
        heading.setForeground(Color.WHITE);
        F1.add(heading);


        JPanel P2 = new JPanel();
        P2.setLayout(null);
        P2.setBackground(new Color(255,204,0));
        P2.setBounds(0, 35, 850, 80);
        F1.add(P2);


        JPanel P1 = new JPanel();
        P1.setLayout(null);
        P1.setBackground(new Color(128,0,128));
        P1.setBounds(0, 0, 850,700);
        F1.add(P1);


        newAccount = new JButton("Create Account");
        newAccount.setBounds(150, 200, 200, 50);
        newAccount.setFont(new Font("Calibri", Font.BOLD, 20));
        newAccount.setBackground(Color.BLACK);
        newAccount.setForeground(Color.WHITE);
        P1.add(newAccount);
        newAccount.addActionListener(this);


        checkBalance = new JButton("Check Balance");
        checkBalance.setBounds(480, 200, 200, 50);
        checkBalance.setFont(new Font("Calibri", Font.BOLD, 20));
        checkBalance.setBackground(Color.BLACK);
        checkBalance.setForeground(Color.WHITE);
        P1.add(checkBalance);
        checkBalance.addActionListener(this);


        Deposit = new JButton("Deposit Amount");
        Deposit.setBounds(150, 300, 200, 50);
        Deposit.setFont(new Font("Calibri", Font.BOLD, 20));
        Deposit.setBackground(Color.BLACK);
        Deposit.setForeground(Color.WHITE);
        P1.add(Deposit);
        Deposit.addActionListener(this);


        Withdraw = new JButton("Withdraw Amount");
        Withdraw.setBounds(480, 300, 200, 50);
        Withdraw.setFont(new Font("Calibri", Font.BOLD, 20));
        Withdraw.setBackground(Color.BLACK);
        Withdraw.setForeground(Color.WHITE);
        P1.add(Withdraw);
        Withdraw.addActionListener(this);


        Transfer = new JButton("Transfer Amount");
        Transfer.setBounds(150, 400, 200, 50);
        Transfer.setFont(new Font("Calibri", Font.BOLD, 20));
        Transfer.setBackground(Color.BLACK);
        Transfer.setForeground(Color.WHITE);
        P1.add(Transfer);
        Transfer.addActionListener(this);


        Exit = new JButton("Exit");
        Exit.setBounds(480, 400, 200, 50);
        Exit.setFont(new Font("Calibri", Font.BOLD, 20));
        Exit.setBackground(Color.BLACK);
        Exit.setForeground(Color.WHITE);
        P1.add(Exit);
        Exit.addActionListener(this);


        F1.setSize(850,650);
        F1.setVisible(true);
        F1.setLocation(250,10);
        F1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == newAccount){
            F1.setVisible(false);
            new addAccount();
        }

        if (e.getSource() == checkBalance) {
            new Balance();
        }

        if (e.getSource() == Deposit) {
            new depositAmount();
        }

        if (e.getSource() == Withdraw) {
            new withdrawAmount();
        }

        if (e.getSource() == Transfer) {
            new transferAmount();
        }

        if (e.getSource() == Exit) {
            F1.setVisible(false);
            F1.dispose();
        }

    }


    public static void main(String[] args) {

        new Bank();
    }
}

