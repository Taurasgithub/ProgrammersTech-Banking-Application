import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Random;
import com.toedter.calendar.JDateChooser;
import net.proteanit.sql.DbUtils;
import java.sql.*;

public class addAccount implements ActionListener {
    JFrame F2;
    Random ran = new Random();
    int number = ran.nextInt(999999);

    JLabel Heading, subHeading, Name, Phone,Email, Father, name, CNIC, addAddress, City, DOB, Date, dateNow, accountNum, randaccountNum;
    JTextField tfPhone,tfName,tfEmail, tfCNIC, tfAddress , tfFather;
    JDateChooser dcdob;
    java.util.Date now;
    JComboBox cbCity;
    JButton add, back, clear;




    public addAccount(){

        F2 = new JFrame("Meezan Bank");
        F2.setLayout(null);

        JPanel P3 = new JPanel();
        P3.setLayout(new FlowLayout());
        P3.setBackground(Color.BLACK);
        P3.setBounds(25, 0, 40, 80);
        F2.add(P3);

        JPanel P1 = new JPanel();
        P1.setLayout(new FlowLayout());
        P1.setBackground(Color.MAGENTA);
        P1.setBounds(0, 35, 700, 70);

        Heading = new JLabel("Meezan Bank");
        Heading.setBounds(250, 35, 500, 40);
        Heading.setFont(new Font("serif", Font.BOLD, 45));
        Heading.setForeground(Color.WHITE);
        P1.add(Heading);
        F2.add(P1);




        JPanel P2 = new JPanel();
        P2.setLayout(new FlowLayout());
        P2.setBackground(Color.GRAY);
        P2.setBounds(300, 105, 600, 60);


        subHeading = new JLabel("Create New Account");
        subHeading.setBounds(200, 200, 500, 50);
        subHeading.setFont(new Font("San_Serif", Font.BOLD, 25));
        subHeading.setForeground(Color.WHITE);
        P2.add(subHeading);
        F2.add(P2);


        Name = new JLabel("Name:");
        Name.setBounds(50, 200, 300, 30);
        Name.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(Name);

        tfName = new JTextField(30);
        tfName.setBounds(125, 200, 300, 30);
        F2.add(tfName);


        CNIC = new JLabel("CNIC:");
        CNIC.setBounds(450, 192, 500, 50);
        CNIC.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(CNIC);

        tfCNIC = new JTextField(30);
        tfCNIC.setBounds(550, 200, 300, 30);
        F2.add(tfCNIC);

        Father = new JLabel("Father");
        Father.setBounds(50,260,300,50);
        Father.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(Father);

        name = new JLabel("Name:");
        name.setBounds(50,280,300,50);
        name.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(name);

        tfFather = new JTextField(30);
        tfFather.setBounds(125, 280, 300, 30);
        F2.add(tfFather);

        addAddress = new JLabel("Address:");
        addAddress.setBounds(50,350,300,50);
        addAddress.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(addAddress);

        tfAddress = new JTextField(30);
        tfAddress.setBounds(125, 360, 300, 30);
        F2.add(tfAddress);

        Phone = new JLabel("Phone:");
        Phone.setBounds(450, 350, 300, 50);
        Phone.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(Phone);

        tfPhone = new JTextField(30);
        tfPhone.setBounds(550, 360, 300, 30);
        F2.add(tfPhone);

        Email = new JLabel("Email:");
        Email.setBounds(50, 420, 300, 50);
        Email.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(Email);

        tfEmail = new JTextField(30);
        tfEmail.setBounds(125, 430, 300, 30);
        F2.add(tfEmail);

        DOB = new JLabel("DOB:");
        DOB.setBounds(450, 270, 300, 50);
        DOB.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(DOB);

        dcdob = new JDateChooser();
        dcdob.setBounds(550, 280, 150, 30);
        F2.add(dcdob);


        City = new JLabel("City:");
        City.setBounds(450, 420, 300, 50);
        City.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(City);

        String typ[] = {"<Select>","Islamabad" , "Lahore" , "Karachi" , "Quetta" , "Sukkur" , "Multan" , "Peshawar" , "Hyderabad" , "Faisalabad" , "Rawalpindi"};
        cbCity = new JComboBox(typ);
        cbCity.setBounds(550, 430, 150, 25);
        F2.add(cbCity);



        Date = new JLabel("Date:");
        Date.setBounds(50,480,300,50);
        Date.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(Date);


        now = new Date();
        dateNow = new JLabel(""+now);
        dateNow.setBounds(125,480,300,50);
        dateNow.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(dateNow);


        accountNum = new JLabel("A/C Num:");
        accountNum.setBounds(452, 480, 300, 50);
        accountNum.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(accountNum);

        randaccountNum = new JLabel("" + number);
        randaccountNum.setBounds(550, 480, 300, 50);
        randaccountNum.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(randaccountNum);



        add = new JButton("Add");
        add.setBackground(Color.GRAY);
        add.setForeground(Color.WHITE);
        add.setBounds(310,550, 80, 35);
        add.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(add);
        add.addActionListener(this);

        clear = new JButton("Clear");
        clear.setBackground(Color.GRAY);
        clear.setForeground(Color.WHITE);
        clear.setBounds(410,550 , 80, 35);
        clear.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(clear);
        clear.addActionListener(this);

        back = new JButton("Back");
        back.setBackground(Color.GRAY);
        back.setForeground(Color.WHITE);
        back.setBounds(510,550 , 80, 35);
        back.setFont(new Font("Calibri", Font.BOLD, 20));
        F2.add(back);
        back.addActionListener(this);

        F2.setSize(900,650);
        F2.setLocation(200,30);
        F2.setVisible(true);
        F2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == add) {
            String name = tfName.getText();
            String fname = tfFather.getText();
            String dob = ((JTextField)dcdob.getDateEditor().getUiComponent()).getText();
            String address = tfAddress.getText();
            String phone = tfPhone.getText();
            String email = tfEmail.getText();
            String cnic = tfCNIC.getText();
            String city = (String) cbCity.getSelectedItem();
            int acNum = number;

            if (name.isEmpty() || fname.isEmpty() || dob.isEmpty() || address.isEmpty() || phone.isEmpty() || email.isEmpty() || cnic.isEmpty() || city.equals("<Select>")) {
                JOptionPane.showMessageDialog(null, "Please Provide Sufficient Account Details!");
            } else {
                String query = "INSERT INTO accountdetails (name, fname, dob, address, phone, email, cnic, city, acNum) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                try {
                    Conn c = new Conn();
                    PreparedStatement ps = c.c.prepareStatement(query);
                    ps.setString(1, name);
                    ps.setString(2, fname);
                    ps.setString(3, dob);
                    ps.setString(4, address);
                    ps.setString(5, phone);
                    ps.setString(6, email);
                    ps.setString(7, cnic);
                    ps.setString(8, city);
                    ps.setInt(9, acNum);

                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Account Created Successfully");
                    F2.setVisible(false);
                    new addAccount();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } else if (e.getSource() == clear) {
            F2.setVisible(false);
            new addAccount();
        } else if (e.getSource() == back) {
            F2.setVisible(false);
            new Bank();
        }
    }
    public static void main(String args[]){
        new addAccount();
    }
}
