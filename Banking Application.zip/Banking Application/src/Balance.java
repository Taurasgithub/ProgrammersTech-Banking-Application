
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import net.proteanit.sql.DbUtils;

public class Balance extends JFrame implements ActionListener {

    JTable table;
    Choice cAccountId;
    JButton search, print, back;

    Balance() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setTitle("Meezan Bank - Account Balance Checker");

        // Set up icon for the window
        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("icons/meezan.png"));
        Image img = icon.getImage();
        Image scaledImage = img.getScaledInstance(112, 112, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        setIconImage(scaledIcon.getImage());

        // Label for account ID search
        JLabel searchLbl = new JLabel("Search by Account ID");
        searchLbl.setBounds(20, 20, 150, 20);
        add(searchLbl);

        // Dropdown for selecting account ID
        cAccountId = new Choice();
        cAccountId.setBounds(180, 20, 150, 20);
        add(cAccountId);

        // Populate account ID dropdown
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM accountdetails");
            while (rs.next()) {
                cAccountId.add(rs.getString("acNum"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Table to display account details
        table = new JTable();

        // Set up table model with initial data
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM accountdetails WHERE accountId = '"+cAccountId.getSelectedItem()+"'");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        JScrollPane jsp = new JScrollPane(table);
        jsp.setBounds(0, 100, 900, 600);
        add(jsp);

        // Search button to query account balance
        search = new JButton("Search");
        search.setBounds(20, 70, 80, 20);
        search.addActionListener(this);
        add(search);

        // Print button to print the table view
        print = new JButton("Print");
        print.setBounds(120, 70, 80, 20);
        print.addActionListener(this);
        add(print);

        // Back button to navigate to previous screen
        back = new JButton("Back");
        back.setBounds(220, 70, 80, 20);
        back.addActionListener(this);
        add(back);

        setSize(900, 700);
        setLocation(300, 100);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == search) {
            String query = "SELECT * FROM accountdetails WHERE accountId = '"+cAccountId.getSelectedItem()+"'";
            try {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery(query);
                table.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == print) {
            try {
                table.print();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            dispose();
            // Assuming you have a main banking screen or menu
            new Bank();
        }
    }

    public static void main(String[] args) {
        new Balance();
    }
}

