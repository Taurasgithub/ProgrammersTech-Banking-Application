import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login implements ActionListener{

    JFrame f;

    JTextField tfusername, tfpassword;
    JLabel heading;

    Login() {
        f = new JFrame();
        f.setTitle("Meezan Bank Login Portal");
        f.getContentPane().setBackground(new Color(128,0,128));
        f.setLayout(null);


        heading = new JLabel("Welcome To Meezan Banking Services");
        heading.setBounds(60, 0, 600, 80);
        heading.setFont(new Font("Elephant", Font.BOLD, 23));
        heading.setForeground(Color.WHITE);
        f.add(heading);

        JPanel P1 = new JPanel();
        P1.setLayout(null);
        P1.setBackground(new Color(255,204,0));
        P1.setBounds(0, 20, 650, 40);
        f.add(P1);

        JLabel lblusername = new JLabel("Username");
        lblusername.setForeground(Color.WHITE);
        lblusername.setBounds(40, 80, 100, 30);
        f.add(lblusername);

        tfusername = new JTextField();
        tfusername.setBounds(150, 80, 150, 30);
        f.add(tfusername);

        JLabel lblpassword = new JLabel("Password");
        lblpassword.setForeground(Color.WHITE);
        lblpassword.setBounds(40, 140, 100, 30);
        f.add(lblpassword);

        tfpassword = new JTextField();
        tfpassword.setBounds(150, 140, 150, 30);
        f.add(tfpassword);

        JButton login = new JButton("LOGIN");
        login.setBounds(188, 200, 80, 30);
        login.setBackground(Color.BLACK);
        login.setForeground(Color.WHITE);
        login.addActionListener(this);
        f.add(login);

        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("icons/meezan.png"));
        Image img = icon.getImage();
        Image scaledImage = img.getScaledInstance(112,112,Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        f.setIconImage(scaledIcon.getImage());

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/login portal.jpg"));
        Image i2 = i1.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(350, 70, 150, 150);
        f.add(image);

        f.setSize(600, 300);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocation(350, 200);
        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            String username = tfusername.getText();
            String password = tfpassword.getText();

            Conn c = new Conn();
            String query = "SELECT * FROM meezanlogin WHERE username = '" + username + "' and password = '" + password + "'";


            ResultSet rs = c.s.executeQuery(query);
            if (rs.next()) {
                f.setVisible(false);
                new Bank();
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password");
                f.setVisible(false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        new Login();
    }
}
