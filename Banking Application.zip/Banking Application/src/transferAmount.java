/*Uimport net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class transferAmount extends JFrame implements ActionListener {

    JTable table;
    Choice cAccountId;
    JButton search,back, tansfer;

    transferAmount() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setTitle("Meezan Bank - Transfer Amount");

        // Set up icon for the window
        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("icons/meezan.png"));
        Image img = icon.getImage();
        Image scaledImage = img.getScaledInstance(112, 112, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        setIconImage(scaledIcon.getImage());

        //Label for depositing amount
        JLabel tansferlbl = new JLabel("tansfer Amount");
        tansferlbl.setBounds(450, 20, 150, 20);
        add(tansferlbl);

        JTextField tansferTF = new JTextField(80);
        tansferTF.setBounds(560, 20, 150, 25);
        add(tansferTF);

        // Label for account ID search
        JLabel searchLbl = new JLabel("Search by Account ID");
        searchLbl.setBounds(20, 20, 150, 20);
        add(searchLbl);

        // Dropdown for selecting account ID
        cAccountId = new Choice();
        cAccountId.setBounds(180, 20, 150, 25);
        add(cAccountId);

        // Populate account ID dropdown
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT DISTINCT accountId FROM accounts");
            while (rs.next()) {
                cAccountId.add(rs.getString("accountId"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Table to display account details
        table = new JTable();

        // Set up table model with initial data
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM accounts WHERE accountId = '"+cAccountId.getSelectedItem()+"'");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        JScrollPane jsp = new JScrollPane(table);
        jsp.setBounds(0, 100, 900, 600);
        add(jsp);

        // Search button to query account balance
        search = new JButton("Search");
        search.setBounds(70, 70, 80, 20);
        search.addActionListener(this);
        add(search);



        // Print button to print the table view
        tansfer = new JButton("tansfer");
        tansfer.setBounds(600, 70, 80, 20);
        tansfer.addActionListener(this);
        add(tansfer);

        // Back button to navigate to previous screen
        back = new JButton("Back");
        back.setBounds(220, 70, 80, 20);
        back.addActionListener(this);
        add(back);

        setSize(900, 700);
        setLocation(300, 100);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == search) {
            String query = "SELECT * FROM accounts WHERE accountId = '"+cAccountId.getSelectedItem()+"'";
            try {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery(query);
                table.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == tansfer) {
            try {
                table.;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            setVisible(false);
            // Assuming you have a main banking screen or menu
            new Bank();
        }
    }

    public static void main(String[] args) {
        new transferAmount();
    }
}
*/


import net.proteanit.sql.DbUtils;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class transferAmount extends JFrame implements ActionListener {

    JTable table;
    Choice cAccountIdFrom, cAccountIdTo;
    JButton search, back, transfer;
    JTextField transferTF;

    transferAmount() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setTitle("Meezan Bank - Transfer Amount");

        // Set up icon for the window
        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("icons/meezan.png"));
        Image img = icon.getImage();
        Image scaledImage = img.getScaledInstance(112, 112, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        setIconImage(scaledIcon.getImage());

        // Label for transferring amount
        JLabel transferlbl = new JLabel("Transfer Amount");
        transferlbl.setBounds(450, 10, 150, 20);
        add(transferlbl);

        transferTF = new JTextField(80);
        transferTF.setBounds(560, 10, 150, 25);
        add(transferTF);

        // Label for source account ID search
        JLabel searchLblFrom = new JLabel("From Account ID");
        searchLblFrom.setBounds(20, 0, 150, 20);
        add(searchLblFrom);

        // Dropdown for selecting source account ID
        cAccountIdFrom = new Choice();
        cAccountIdFrom.setBounds(180, 0, 150, 25);
        add(cAccountIdFrom);

        // Label for destination account ID search
        JLabel searchLblTo = new JLabel("To Account ID");
        searchLblTo.setBounds(20, 40, 150, 20);
        add(searchLblTo);

        // Dropdown for selecting destination account ID
        cAccountIdTo = new Choice();
        cAccountIdTo.setBounds(180, 40, 150, 25);
        add(cAccountIdTo);

        // Populate account ID dropdowns
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM accountdetails");
            while (rs.next()) {
                cAccountIdFrom.add(rs.getString("acNum"));
                cAccountIdTo.add(rs.getString("acNum"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Table to display account details
        table = new JTable();
        JScrollPane jsp = new JScrollPane(table);
        jsp.setBounds(0, 100, 900, 600);
        add(jsp);

        // Search button to query account balance
        search = new JButton("Search");
        search.setBounds(70, 100, 80, 20);
        search.addActionListener(this);
        add(search);

        // Transfer button to process the transfer
        transfer = new JButton("Transfer");
        transfer.setBounds(600, 70, 90, 20);
        transfer.addActionListener(this);
        add(transfer);

        // Back button to navigate to previous screen
        back = new JButton("Back");
        back.setBounds(220, 70, 80, 20);
        back.addActionListener(this);
        add(back);

        setSize(900, 700);
        setLocation(300, 100);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == search) {
            String query = "SELECT * FROM accountdetails WHERE accountId = '" + cAccountIdFrom.getSelectedItem() + "'";
            try {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery(query);
                table.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == transfer) {
            try {
                String accountIdFrom = cAccountIdFrom.getSelectedItem();
                String accountIdTo = cAccountIdTo.getSelectedItem();
                int amount = Integer.parseInt(transferTF.getText());

                if (accountIdFrom.equals(accountIdTo)) {
                    JOptionPane.showMessageDialog(null, "Cannot transfer to the same account!");
                    return;
                }

                Conn c = new Conn();
                // Check balances of both accounts
                ResultSet rsFrom = c.s.executeQuery("SELECT balance FROM accountdetails WHERE accountId = '" + accountIdFrom + "'");
                ResultSet rsTo = c.s.executeQuery("SELECT balance FROM accountdetails WHERE accountId = '" + accountIdTo + "'");
                if (rsFrom.next() && rsTo.next()) {
                    int balanceFrom = rsFrom.getInt("balance");
                    int balanceTo = rsTo.getInt("balance");

                    if (balanceFrom >= amount) {
                        // Perform the transfer
                        int newBalanceFrom = balanceFrom - amount;
                        int newBalanceTo = balanceTo + amount;

                        c.s.executeUpdate("UPDATE accountdetails SET balance = " + newBalanceFrom + " WHERE accountId = '" + accountIdFrom + "'");
                        c.s.executeUpdate("UPDATE accountdetails SET balance = " + newBalanceTo + " WHERE accountId = '" + accountIdTo + "'");

                        JOptionPane.showMessageDialog(null, "Transfer successful!");

                        // Refresh the table data
                        ResultSet rsUpdated = c.s.executeQuery("SELECT * FROM accountdetails WHERE accountId = '" + accountIdFrom + "'");
                        table.setModel(DbUtils.resultSetToTableModel(rsUpdated));
                    } else {
                        JOptionPane.showMessageDialog(null, "Insufficient balance!");
                    }
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid amount.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == back) {
            dispose();
            // Assuming you have a main banking screen or menu
            new Bank();
        }
    }

    public static void main(String[] args) {
        new transferAmount();
    }
}

